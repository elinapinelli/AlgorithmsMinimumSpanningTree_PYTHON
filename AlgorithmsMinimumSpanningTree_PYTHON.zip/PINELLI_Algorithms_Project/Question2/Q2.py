def MinimSpanTree(graph):
    """
    Finds the Minimum Spanning Tree (MST) of a given graph.

    Args:
        graph (dict): The graph represented as a dictionary.

    Returns:
        tuple: A tuple containing the total cost of the MST, the MST edges, and a message indicating the connectivity status.
    """
    if not graph:
        return 0, [], "No Villages found."
    # If the graph is empty, return 0 for the cost, an empty list for edges, and a message indicating an empty graph

    start_node = list(graph.keys())[0]
    visited_nodes = set([start_node])
    edges = sorted([(cost, start_node, adjacent_nodes) for adjacent_nodes, cost in graph[start_node]])
    mst_cost, mst_edges = 0, []

    while edges:
        cost, previous_node, adjacent_nodes = edges.pop(0)
        if adjacent_nodes not in visited_nodes:
            visited_nodes.add(adjacent_nodes)
            mst_cost += cost
            mst_edges.append((previous_node, adjacent_nodes, cost))
            edges.extend((next_cost, adjacent_nodes, next_to) for next_to, next_cost in graph[adjacent_nodes] if
                         next_to not in visited_nodes)
            edges.sort()

    if len(graph) != len(visited_nodes):
        return ('Some villages may not be reachable from others.'), [], 0  # Return a message indicating some villages may not be reachable, along with an empty list for edges and 0 for the cost

    return mst_cost, mst_edges, 'All villages are reachable from each other.'  # Return the total cost of the MST, MST edges, and a message indicating all villages are reachable


def read_graph_from_file(file_path):
    graph = {}
    with open(file_path, 'r') as file:
        num_villages = int(file.readline().strip())
        for _ in range(num_villages):
            line = file.readline().strip().split()
            village = line[0]
            edges = []
            for i in range(1, len(line), 3):
                neighbor = line[i]
                cost = int(line[i + 1])
                edges.append((neighbor, cost))
            graph[village] = edges
    return graph

def find_root(roots, node):
    if roots[node] != node:
        roots[node] = find_root(roots, roots[node])
    return roots[node]

def unite_sets(roots, depths, node1, node2):
    root1 = find_root(roots, node1)
    root2 = find_root(roots, node2)
    if root1 != root2:
        if depths[root1] < depths[root2]:
            roots[root1] = root2
        elif depths[root1] > depths[root2]:
            roots[root2] = root1
        else:
            roots[root2] = root1
            depths[root1] += 1

def compute_mst(network):
    mst = []
    edges = []

    for node in network:
        for neighbor, weight in network[node]:
            edges.append((weight, node, neighbor))
    edges.sort()

    roots = {node: node for node in network}
    depths = {node: 0 for node in network}

    for weight, node1, node2 in edges:
        if find_root(roots, node1) != find_root(roots, node2):
            mst.append((node1, node2, weight))
            unite_sets(roots, depths, node1, node2)

    return mst

def held_karp_tsp(graph):
    def tsp_dp(curr, visited):
        if (curr, visited) in memo:
            return memo[(curr, visited)]

        if visited == target_mask:
            return {(): 0}

        min_cost = float('inf')
        min_path = None

        for neighbor, weight in graph[curr]:
            if (visited >> neighbor) & 1 == 0:
                new_visited = visited | (1 << neighbor)
                cost = weight + tsp_dp(neighbor, new_visited)

                if cost < min_cost:
                    min_cost = cost
                    min_path = neighbor

        memo[(curr, visited)] = min_cost
        return min_cost

    start_node = list(graph.keys())[0]
    target_mask = (1 << len(graph)) - 1
    memo = {}

    min_cost = tsp_dp(start_node, 1 << start_node)

    return min_cost

def main():
    file_path = 'graph_data.txt'  # Change to the path of your text file
    graph = read_graph_from_file(file_path)
    mst_result = MinimSpanTree(graph)
    mst_cost = mst_result[0]
    mst_edges = mst_result[1]
    mst_message = mst_result[2]
    print("Edges in the MST:")
    for edge in mst_edges:
        print(edge[0], "to", edge[1], ">", edge[2])
    print("Total Cost of Minimum Spanning Tree:", mst_cost)
    print("Connectivity Status:", mst_message)

if __name__ == "__main__":
    main()



