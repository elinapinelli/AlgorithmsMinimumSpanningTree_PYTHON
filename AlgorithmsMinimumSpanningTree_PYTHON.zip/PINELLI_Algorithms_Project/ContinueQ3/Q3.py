def MinimSpanTree(graph):
    """
    Finds the Minimum Spanning Tree (MST) of a given graph considering clearing and traversal costs.

    Args:
        graph (dict): The graph represented as a dictionary.

    Returns:
        tuple: A tuple containing the total cost of the MST, the MST edges, and a message indicating the connectivity status.
    """
    if not graph:
        return 0, [], "No Villages found."

    start_node = list(graph.keys())[0]
    visited_nodes = set([start_node])
    edges = sorted([(clear_cost + traverse_cost, start_node, adjacent_nodes, clear_cost, traverse_cost)
                    for adjacent_nodes, (clear_cost, traverse_cost) in graph[start_node]])
    mst_cost, mst_edges = 0, []

    while edges:
        total_cost, previous_node, adjacent_nodes, clear_cost, traverse_cost = edges.pop(0)[0:5]
        if adjacent_nodes not in visited_nodes:
            visited_nodes.add(adjacent_nodes)
            mst_cost += total_cost
            mst_edges.append((previous_node, adjacent_nodes, clear_cost, traverse_cost))
            edges.extend((next_clear_cost + next_traverse_cost, adjacent_nodes, next_to, next_clear_cost, next_traverse_cost)
                         for next_to, (next_clear_cost, next_traverse_cost) in graph[adjacent_nodes] if next_to not in visited_nodes)
            edges.sort()

    if len(graph) != len(visited_nodes):
        return ('Some villages may not be reachable from others.'), [], 0  # Return a message indicating some villages may not be reachable, along with an empty list for edges and 0 for the cost

    return mst_cost, mst_edges, 'All villages are reachable from each other.'  # Return the total cost of the MST, MST edges, and a message indicating all villages are reachable


def read_graph_from_file(file_path):
    graph = {}
    with open(file_path, 'r') as file:
        num_villages = int(file.readline().strip())
        for _ in range(num_villages):
            line = file.readline().strip().split()
            village = line[0]
            edges = []
            for i in range(1, len(line), 3):  # Iterate over pairs of elements
                neighbor = line[i]
                clear_cost = int(line[i + 1])
                traverse_cost = int(line[i + 2])
                edges.append((neighbor, (clear_cost, traverse_cost)))
            graph[village] = edges
    return graph

def main():
    file_path = 'graph_data.txt'  # Change to the path of your text file
    graph = read_graph_from_file(file_path)
    mst_result = MinimSpanTree(graph)
    mst_cost = mst_result[0]
    mst_edges = mst_result[1]
    mst_message = mst_result[2]
    print("Edges in the MST:")
    for edge in mst_edges:
        print(edge[0], "to", edge[1], "(Clearing Cost:", edge[2], ", Traversal Cost:", edge[3], ")")
    print("Total Cost of Minimum Spanning Tree:", mst_cost)
    print("Connectivity Status:", mst_message)

if __name__ == "__main__":
    main()
